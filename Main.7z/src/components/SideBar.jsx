import * as React from 'react';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
// import Button from '@mui/material/Button';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
// import InboxIcon from '@mui/icons-material/MoveToInbox';
// import MailIcon from '@mui/icons-material/Mail';
import HomeIcon from '@mui/icons-material/Home';
import ReceiptLongIcon from '@mui/icons-material/ReceiptLong';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import MenuIcon from '@mui/icons-material/Menu';
import LoginIcon from '@mui/icons-material/Login';
import { useNavigate } from 'react-router-dom';
// import "../CSS/NavigationBar.css"
const SideBar = () => {
    const [open, setOpen] = React.useState(false);
    const navigate = useNavigate();
    const toggleDrawer = (newOpen) => () => {
        setOpen(newOpen);
      };
      
      const handleNavigation = (path) => () => {
        navigate(path);
        setOpen(false);
    };
      const DrawerList = (
        <Box sx={{ width: 250 }} role="presentation" onClick={toggleDrawer(false)}>
          <List>
            {/* {['Inbox', 'Starred', 'Send email', 'Drafts'].map((text, index) => (
              <ListItem key={text} disablePadding>
                <ListItemButton>
                  <ListItemIcon>
                    {index % 2 === 0 ? <InboxIcon /> : <MailIcon />}
                  </ListItemIcon>
                  <ListItemText primary={text} />
                </ListItemButton>
              </ListItem>
            ))} */}

            <ListItem disablePadding>
            <ListItemButton onClick={handleNavigation("/")}> I
            <ListItemIcon>
            <HomeIcon />
            </ListItemIcon>
            <ListItemText primary={"Home"} />
            </ListItemButton>
            </ListItem>

            <ListItem disablePadding>
            <ListItemButton onClick={handleNavigation("/account")}> I
            <ListItemIcon>
            <AccountCircleIcon/>
            </ListItemIcon>
            <ListItemText primary={"Account"} />
            </ListItemButton>
            </ListItem>

            <ListItem disablePadding>
            <ListItemButton onClick={handleNavigation("/portfolio")}> I
            <ListItemIcon>
            <AccountCircleIcon/>
            </ListItemIcon>
            <ListItemText primary={"Portfolio"} />
            </ListItemButton>
            </ListItem>

            <ListItem disablePadding>
            <ListItemButton onClick={handleNavigation("/orders")}> I
            <ListItemIcon>
            <ReceiptLongIcon />
            </ListItemIcon>
            <ListItemText primary={"Orders"} />
            </ListItemButton>
            </ListItem>

            


          </List>
          <Divider />
          <List>
            {/* {['All mail', 'Trash', 'Spam'].map((text, index) => (
              <ListItem key={text} disablePadding>
                <ListItemButton>
                  <ListItemIcon>
                    {index % 2 === 0 ? <InboxIcon /> : <MailIcon />}
                  </ListItemIcon>
                  <ListItemText primary={text} />
                </ListItemButton>
              </ListItem>
            ))} */}
            <ListItem disablePadding>
            <ListItemButton onClick={handleNavigation("/login")}> I
            <ListItemIcon>
            <LoginIcon />
            </ListItemIcon>
            <ListItemText primary={"Login"} />
            </ListItemButton>
            </ListItem>
          </List>
        </Box>
      );
    return(
        <div>
      {/* <Button onClick={toggleDrawer(true)}>Open drawer</Button>
      <Drawer open={open} onClose={toggleDrawer(false)}>
        {DrawerList}
      </Drawer> */}

      <React.Fragment>
        <MenuIcon 
        onClick={
            toggleDrawer("left",true)
        }></MenuIcon>
         <Drawer open={open} onClose={toggleDrawer(false)}>
        {DrawerList}
      </Drawer> 
      </React.Fragment>
    </div>
    );
}

export default SideBar