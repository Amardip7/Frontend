import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { fetchFOData } from '../services/F&OService';
import '../CSS/PositionsTable.css';

const FuturesandOptions = () => {
  const location = useLocation();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [expandedGroups, setExpandedGroups] = useState({});
  const [checkedContracts, setCheckedContracts] = useState({});

  const { uccId } = location.state || {}; // Get the UCC ID from navigation state

  useEffect(() => {
    const fetchData = async () => {
      if (uccId) {
        try {
          const response = await fetchFOData(uccId);
          setData(response);
          initializeExpandedGroups(response);
        } catch (error) {
          console.error(error);
        } finally {
          setLoading(false);
        }
      }
    };
    fetchData();
  }, [uccId]);

  const initializeExpandedGroups = (data) => {
    const initialExpandedGroups = {};
    const initialCheckedContracts = {};
    if (data.ffo_contract) {
      data.ffo_contract.forEach((contract) => {
        const groupName = contract.split('-')[1];
        if (!initialExpandedGroups[groupName]) {
          initialExpandedGroups[groupName] = true;
        }
        initialCheckedContracts[contract] = true; // Checkboxes selected by default
      });
    }
    setExpandedGroups(initialExpandedGroups);
    setCheckedContracts(initialCheckedContracts);
  };

  const toggleGroupExpansion = (group) => {
    setExpandedGroups((prev) => ({
      ...prev,
      [group]: !prev[group],
    }));
  };

  const handleCheckboxChange = (contract) => {
    setCheckedContracts((prev) => ({
      ...prev,
      [contract]: !prev[contract],
    }));
  };

  const handleSquareOff = (contract) => {
    console.log(`Square off contract: ${contract}`);
    // Add your square off logic here
  };

  const handleSquareOffAll = (groupName) => {
    console.log(`Square off all contracts in group: ${groupName}`);
    const contractsToSquareOff = Object.keys(checkedContracts).filter(
      (contract) => checkedContracts[contract] && contract.includes(groupName)
    );
    contractsToSquareOff.forEach((contract) => handleSquareOff(contract));
  };

  const groupDataByGroupName = () => {
    const groupedData = {};
    if (data.ffo_contract) {
      data.ffo_contract.forEach((contract, index) => {
        const groupName = contract.split('-')[1];
        if (!groupedData[groupName]) {
          groupedData[groupName] = {
            contracts: [],
            totalQty: 0,
          };
        }
        groupedData[groupName].contracts.push({
          contract,
          position: data.ffo_pstn[index],
          qty: data.ffo_qty[index],
          avgCostPrice: data.ffo_avg_prc[index],
        });
        groupedData[groupName].totalQty += data.ffo_qty[index];
      });
    }
    return groupedData;
  };

  const renderTable = () => {
    if (loading) return <p>Loading...</p>;
    if (!data || !data.ffo_contract) return <p>No data found</p>;

    const groupedData = groupDataByGroupName();

    return (
      <div>
        {Object.keys(groupedData).map((groupName, groupIndex) => (
          <div key={groupIndex} className="group-section">
            <div className="group-header" onClick={() => toggleGroupExpansion(groupName)}>
              <button className="circular-btn">
                {expandedGroups[groupName] ? '-' : '+'}
              </button>
              <span style={{ marginLeft: '10px' }}>{groupName}</span>
            </div>
            {expandedGroups[groupName] && (
              <table className="table table-striped">
                <thead>
                  <tr>
                    <th>Contract</th>
                    <th>Position</th>
                    <th>Quantity</th>
                    <th>Average Price</th>
                    <th>Action</th> {/* Column for action */}
                  </tr>
                </thead>
                <tbody>
                  {groupedData[groupName].contracts.map((contractData, index) => (
                    <tr key={index}>
                      <td>
                        <input
                          type="checkbox"
                          checked={checkedContracts[contractData.contract]}
                          onChange={() => handleCheckboxChange(contractData.contract)}
                        />
                        <span style={{ marginLeft: '5px' }}>{contractData.contract}</span>
                      </td>
                      <td>{contractData.position}</td>
                      <td>{contractData.qty}</td>
                      <td>{contractData.avgCostPrice.toFixed(2)}</td>
                      <td>
                        <button
                          className="btn btn-outline-primary btn-sm mr-1"
                          onClick={() => handleSquareOff(contractData.contract)}
                        >
                          Square Off
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
            {/* Group Total row always visible */}
            <table className="table table-striped" style={{ marginBottom: '0' }}>
              <tbody>
                <tr className="font-weight-bold">
                  <td>Group Total</td>
                  <td></td>
                  <td>{groupedData[groupName].totalQty}</td>
                  <td></td>
                  <td>
                    <button
                      className="btn btn-outline-danger btn-sm mr-1"
                      onClick={() => handleSquareOffAll(groupName)}
                    >
                      Square Off All
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div>
      {renderTable()}
    </div>
  );
};

export default FuturesandOptions;
