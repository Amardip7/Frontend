'use strict';
require('../register')('pinkie', {Promise: require('pinkie')})
