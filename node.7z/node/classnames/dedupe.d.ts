import classNames = require('./index.js');

export as namespace classNames;

export = classNames;
