'use strict';
var parent = require('../../stable/map/group-by');
require('../../modules/esnext.map.group-by');

module.exports = parent;
