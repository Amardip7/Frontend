'use strict';
var parent = require('../../stable/function');
require('../../modules/esnext.function.metadata');

module.exports = parent;
