'use strict';
var parent = require('../../stable/url/can-parse');

module.exports = parent;
