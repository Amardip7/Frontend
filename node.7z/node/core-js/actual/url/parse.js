'use strict';
var parent = require('../../stable/url/parse');

module.exports = parent;
