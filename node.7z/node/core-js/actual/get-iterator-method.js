'use strict';
var parent = require('../stable/get-iterator-method');

module.exports = parent;
