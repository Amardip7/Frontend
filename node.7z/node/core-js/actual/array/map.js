'use strict';
var parent = require('../../stable/array/map');

module.exports = parent;
