'use strict';
var parent = require('../../stable/array/every');

module.exports = parent;
