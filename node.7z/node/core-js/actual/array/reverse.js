'use strict';
var parent = require('../../stable/array/reverse');

module.exports = parent;
