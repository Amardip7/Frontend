'use strict';
require('../../modules/esnext.array.find-last-index');
var parent = require('../../stable/array/find-last-index');

module.exports = parent;
