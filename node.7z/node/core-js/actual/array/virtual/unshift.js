'use strict';
var parent = require('../../../stable/array/virtual/unshift');

module.exports = parent;
