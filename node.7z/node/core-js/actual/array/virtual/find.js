'use strict';
var parent = require('../../../stable/array/virtual/find');

module.exports = parent;
