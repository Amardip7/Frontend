'use strict';
var parent = require('../../../stable/array/virtual/find-index');

module.exports = parent;
