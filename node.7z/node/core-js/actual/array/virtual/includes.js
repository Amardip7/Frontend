'use strict';
var parent = require('../../../stable/array/virtual/includes');

module.exports = parent;
