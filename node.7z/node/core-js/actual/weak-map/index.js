'use strict';
var parent = require('../../stable/weak-map');

module.exports = parent;
