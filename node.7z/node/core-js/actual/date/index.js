'use strict';
var parent = require('../../stable/date');

module.exports = parent;
