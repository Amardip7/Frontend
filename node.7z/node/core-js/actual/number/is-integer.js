'use strict';
var parent = require('../../stable/number/is-integer');

module.exports = parent;
