'use strict';
require('../../modules/esnext.data-view.set-float16');
