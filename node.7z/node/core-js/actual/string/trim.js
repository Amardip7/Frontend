'use strict';
var parent = require('../../stable/string/trim');

module.exports = parent;
