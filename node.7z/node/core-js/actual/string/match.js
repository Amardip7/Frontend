'use strict';
var parent = require('../../stable/string/match');

module.exports = parent;
