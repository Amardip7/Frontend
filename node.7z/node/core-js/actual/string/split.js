'use strict';
var parent = require('../../stable/string/split');

module.exports = parent;
