'use strict';
var parent = require('../../stable/string/pad-start');

module.exports = parent;
