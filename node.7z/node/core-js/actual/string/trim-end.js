'use strict';
var parent = require('../../stable/string/trim-end');

module.exports = parent;
