'use strict';
var parent = require('../../../stable/string/virtual/ends-with');

module.exports = parent;
