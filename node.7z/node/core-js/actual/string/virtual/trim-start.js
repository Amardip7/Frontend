'use strict';
var parent = require('../../../stable/string/virtual/trim-start');

module.exports = parent;
