'use strict';
var parent = require('../../../stable/string/virtual/repeat');

module.exports = parent;
