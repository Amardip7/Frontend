'use strict';
var parent = require('../../../stable/string/virtual/small');

module.exports = parent;
