'use strict';
var parent = require('../../stable/string/big');

module.exports = parent;
