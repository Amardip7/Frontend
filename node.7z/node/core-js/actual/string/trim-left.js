'use strict';
var parent = require('../../stable/string/trim-left');

module.exports = parent;
