'use strict';
var parent = require('../../stable/promise/all-settled');

module.exports = parent;
