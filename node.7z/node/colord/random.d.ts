import { Colord } from "./colord";
export declare const random: () => Colord;
