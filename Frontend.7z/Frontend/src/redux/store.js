// src/redux/store.js
import { configureStore } from '@reduxjs/toolkit';
import uccIdReducer from './slices/uccIdSlice';
import foReducer from './slices/foSlice';
import equityReducer from './slices/equitySlice';
import commodityReducer from './slices/commoditySlice';
import componentReducer from './slices/componentSlice'

export const store = configureStore({
  reducer: {
    uccId: uccIdReducer,
    foData: foReducer,
    equityData: equityReducer,
    commodityData: commodityReducer,
    component: componentReducer,
  },
});

export default store;