// src/redux/slices/componentSlice.js
import { createSlice } from '@reduxjs/toolkit';

const componentSlice = createSlice({
  name: 'component',
  initialState: {
    componentType: null,  // Initial state for componentType
  },
  reducers: {
    setComponentType: (state, action) => {
      state.componentType = action.payload;  // Set the componentType based on the payload
    },
  },
});

export const { setComponentType } = componentSlice.actions;

export default componentSlice.reducer;
