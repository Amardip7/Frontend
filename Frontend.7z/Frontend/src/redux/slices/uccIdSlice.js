// src/redux/slices/uccIdSlice.js
import { createSlice } from '@reduxjs/toolkit';

const uccIdSlice = createSlice({
  name: 'uccId',
  initialState: '',
  reducers: {
    setUccId: (state, action) => action.payload,
    clearUccId: () => '',
  },
});

export const { setUccId, clearUccId } = uccIdSlice.actions;

export default uccIdSlice.reducer;