import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  equityOpenPositions: [],  // Store the equity open positions here
  squareOffData: null,  // Store square-off data here
};

const equitySlice = createSlice({
  name: 'equityData',
  initialState,
  reducers: {
    setEquityOpenPositions: (state, action) => {
      state.equityOpenPositions = action.payload;
    },
    setSquareOffData: (state, action) => {
      state.squareOffData = action.payload;
    },
  },
});

export const { setEquityOpenPositions, setSquareOffData } = equitySlice.actions;

export default equitySlice.reducer;
