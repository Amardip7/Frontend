// redux/slices/commoditySlice.js
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  commodityOpenPositions: [],
  squareOffData: null,  // To store square-off contract details
};

const commoditySlice = createSlice({
  name: 'commodityData',
  initialState,
  reducers: {
    setCommodityOpenPositions: (state, action) => {
      state.commodityOpenPositions = action.payload;  // Store open positions
    },
    setSquareOffData: (state, action) => {
      state.squareOffData = action.payload;  // Store square-off data
    },
    clearSquareOffData: (state) => {
      state.squareOffData = null;  // Clear square-off data after it's processed
    },
  },
});

export const { setCommodityOpenPositions, setSquareOffData, clearSquareOffData } = commoditySlice.actions;

export default commoditySlice.reducer;
