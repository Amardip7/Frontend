// src/redux/slices/foSlice.js
import { createSlice } from '@reduxjs/toolkit';

const foSlice = createSlice({
  name: 'foData',
  initialState: {
    foOpenPositions: [],
    squareOffData: null,
  },
  reducers: {
    setFOOpenPositions: (state, action) => {
      state.foOpenPositions = action.payload;
    },
    setSquareOffData: (state, action) => {
      state.squareOffData = action.payload;
    },
  },
});

export const { setFOOpenPositions, setSquareOffData } = foSlice.actions;
export default foSlice.reducer;
