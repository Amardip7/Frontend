import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../CSS/OrderVerification.css';
import { postFNOData } from '../services/F&OService';
import { useSelector } from 'react-redux'; // Import useSelector to access Redux state

const OrderVerification = () => {
  const navigate = useNavigate();

  // Access squareOffData and uccId from Redux
  const squareOffData = useSelector((state) => state.foData.squareOffData);
  const uccId = useSelector((state) => state.uccId);

  // Log the entire squareOffData object to verify its structure
  console.log('squareOffData from Redux:', squareOffData);
  console.log('UCC ID for square-off:', uccId);

  const handleProceed = async () => {
    if (squareOffData && squareOffData.contracts && squareOffData.contracts.length > 0) {
      const firstContract = squareOffData.contracts[0];  // First contract to get product type
      const prodTyp = firstContract?.FCP_PRDCT_TYP;
  
      if (!uccId || !prodTyp) {
        console.error('Required data is missing for proceeding');
        return;
      }
  
      try {
        const dataToSend = {
          FcpDetails: squareOffData.contracts  // Send all contracts
        };
  
        console.log('Data being sent to backend:', dataToSend);
        await postFNOData(dataToSend, uccId, prodTyp);
        navigate('/acknowledgement');
      } catch (error) {
        console.error('Error during the proceed action:', error);
      }
    } else {
      console.error('No data available for proceeding');
    }
  };
  

  return (
    <div className="order-verification-container">
      <h2 className="order-title">Order Verification</h2>
      <div className="order-details">
        {squareOffData && squareOffData.contracts && squareOffData.contracts.length > 0 ? (
          squareOffData.contracts.map((contractsData, index) => (
            <div key={index} className="order-section">
              <div className="order-column">
                <div className="order-field">
                  <span>Action: </span>
                  <strong>{contractsData.FFO_PSTN}</strong>
                </div>
                <div className="order-field">
                  <span>Product: </span>
                  <strong>{contractsData.FCP_PRDCT_TYP}</strong>
                </div>
                <div className="order-field">
                  <span>Square Off Quantity: </span>
                  <strong>{squareOffData.totalQty}</strong>
                </div>
                <div className="order-field">
                  <span>contracts Expiry Date: </span>
                  <strong>{contractsData.FCP_EXPRY_DT}</strong>
                </div>
              </div>
              <div className="order-column">
                <div className="order-field">
                  <span>Exchange: </span>
                  <strong>{contractsData.FCP_XCHNG_CD}</strong>
                </div>
                <div className="order-field">
                  <span>contracts: </span>
                  <strong>{contractsData.FFO_contracts}</strong>
                </div>
                <div className="order-field">
                  <span>Order Type: </span>
                  <strong>{contractsData.orderType || 'Market'}</strong>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p>No data available for verification</p>
        )}
      </div>

      <div className="order-buttons">
        <button className="back-btn" onClick={() => navigate(-1)}>Back</button>
        <button className="proceed-btn" onClick={handleProceed}>Proceed</button>
      </div>
    </div>
  );
};

export default OrderVerification;


// import React from 'react';
// import { useLocation, useNavigate } from 'react-router-dom';
// import '../CSS/OrderVerification.css';
// import { postCommodityData } from '../services/CommodityService';
// import { postEquityData } from '../services/EquityService';
// import { postFNOData } from '../services/F&OService';

// const OrderVerification = () => {
//   const location = useLocation();
//   const navigate = useNavigate();

//   // Accessing squareOffData and determine its type
//   const { squareOffData, type } = location.state || {}; // Assume type is passed as part of state to differentiate data
//   const contracts = squareOffData?.contracts || squareOffData?.FcpDetails || [];
//   const totalQty = squareOffData?.totalQty;

//   // Log the received data for debugging
//   console.log('squareOffData:', squareOffData);
//   console.log('Contracts:', contracts);

//   // Retrieve uccId from sessionStorage or from the first contract
//   const uccId = sessionStorage.getItem('uccId') || contracts[0]?.uccId;
//   console.log('UCC ID for square-off:', uccId);

//   const handleProceed = async () => {
//     if (contracts.length > 0 && uccId) {
//       try {
//         let postData = [];
//         let postFunction;

//         switch (type) {
//           case 'commodity':
//             postData = contracts;
//             postFunction = postCommodityData;
//             break;
//           case 'equity':
//             postData = contracts.map(contract => ({ ...contract }));
//             postFunction = postEquityData;
//             break;
//           case 'fno':
//             postData = { FcpDetails: contracts };
//             postFunction = postFNOData;
//             break;
//           default:
//             console.error('Unknown product type');
//             return;
//         }

//         console.log('Payload data:', postData);

//         // Post data based on the product type
//         await postFunction(postData, uccId);
//         navigate('/acknowledgement'); // Redirect to the next page on success
//       } catch (error) {
//         console.error('Error during the proceed action:', error);
//       }
//     } else {
//       console.error('No data available for proceeding');
//     }
//   };

//   return (
//     <div className="order-verification-container">
//       <h2 className="order-title">Order Verification</h2>
//       <div className="order-details">
//         {contracts.length > 0 ? (
//           contracts.map((contractData, index) => (
//             <div key={index} className="order-section">
//               <div className="order-column">
//                 <div className="order-field">
//                   <span>Product: </span>
//                   <strong>{contractData.ccp_prdct_typ || contractData.epb_stck_cd || contractData.FCP_PRDCT_TYP}</strong>
//                 </div>
//                 <div className="order-field">
//                   <span>Square Off Quantity: </span>
//                   <strong>{totalQty}</strong>
//                 </div>
//                 {contractData.ccp_expry_dt || contractData.epb_expiry_dt || contractData.FCP_EXPRY_DT ? (
//                   <div className="order-field">
//                     <span>Contract Expiry Date: </span>
//                     <strong>{contractData.ccp_expry_dt || contractData.epb_expiry_dt || contractData.FCP_EXPRY_DT}</strong>
//                   </div>
//                 ) : null}
//               </div>
//               <div className="order-column">
//                 <div className="order-field">
//                   <span>Exchange: </span>
//                   <strong>{contractData.ccp_xchng_cd || contractData.epb_xchng_cd || contractData.FCP_XCHNG_CD}</strong>
//                 </div>
//                 <div className="order-field">
//                   <span>Contract: </span>
//                   <strong>{contractData.ccp_undrlyng || contractData.epb_stck_cd || contractData.FFO_CONTRACT}</strong>
//                 </div>
//                 <div className="order-field">
//                   <span>Order Type: </span>
//                   <strong>{contractData.orderType || 'Market'}</strong>
//                 </div>
//               </div>
//             </div>
//           ))
//         ) : (
//           <p>No data available for verification</p>
//         )}
//       </div>

//       <div className="order-buttons">
//         <button className="back-btn" onClick={() => navigate(-1)}>Back</button>
//         <button className="proceed-btn" onClick={handleProceed}>Proceed</button>
//       </div>
//     </div>
//   );
// };

// export default OrderVerification;