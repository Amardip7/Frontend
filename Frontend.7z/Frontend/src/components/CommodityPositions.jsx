import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { fetchCommodityData } from "../services/CommodityService";
import { setCommodityOpenPositions, setSquareOffData } from "../redux/slices/commoditySlice";
import "../CSS/PositionsTable.css";

const CommodityPositions = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const uccId = useSelector((state) => state.uccId); //access uccid from redux store
  const commodityOpenPositions = useSelector((state) => state.commodityData.commodityOpenPositions);

  const [loading, setLoading] = useState(true);
  const [checkedContracts, setCheckedContracts] = useState({});
  const [expandedGroups, setExpandedGroups] = useState({});
  const [error, setError] = useState(null);
  const componentType = useSelector((state) => state.component.componentType);

  useEffect(() => {
    const fetchData = async () => {
      if (uccId) {
        try {
          const response = await fetchCommodityData(uccId);
          console.log("Fetched Data:", response); // Log data to verify structure
          dispatch(setCommodityOpenPositions(response.commodity_positions));  // Store commodity positions in Redux
          initializeGroups(response.commodity_positions);
        } catch (err) {
          setError("Failed to fetch commodity data.");
          console.error(err);
        } finally {
          setLoading(false);
        }
      }
    };
    fetchData();
  }, [uccId, dispatch]);

  const initializeGroups = (data) => {
    const initialCheckedContracts = {};
    const initialExpandedGroups = {};
    if (data) {
      data.forEach((item) => {
        const groupName = item.ccp_undrlyng; // Assuming this is the grouping field
        if (!initialExpandedGroups[groupName]) {
          initialExpandedGroups[groupName] = true; // Expand by default
        }
        initialCheckedContracts[groupName] = false; // Start with checkboxes not checked
      });
    }
    setExpandedGroups(initialExpandedGroups);
    setCheckedContracts(initialCheckedContracts);
  };

  const toggleGroupExpansion = (group) => {
    setExpandedGroups((prev) => ({
      ...prev,
      [group]: !prev[group],
    }));
  };

  const handleCheckboxChange = (contract) => {
    setCheckedContracts((prev) => ({
      ...prev,
      [contract]: !prev[contract],
    }));
  };

  const handleSquareOff = (position) => {
    const squareOffData = {
      contracts: [position], // Pass the entire position object directly
    };
    dispatch(setSquareOffData(squareOffData));  // Save square-off data to Redux
    navigate('/squareoff');
  };

  const handleSquareOffAll = () => {
    const contractsToSquareOff = Object.keys(checkedContracts).filter(
      (contract) => checkedContracts[contract]
    );

    const contractsDetails = contractsToSquareOff.map((contract) => {
      return commodityOpenPositions.find(c => c.ccp_undrlyng === contract); // Get full contract details
    }).filter(Boolean); // Filter out any undefined values

    const squareOffData = {
      contracts: contractsDetails,
    };

    dispatch(setSquareOffData(squareOffData));  // Save square-off data to Redux
    navigate('/squareoff');
  };

  const groupDataByGroupName = () => {
    const groupedData = {};
    if (commodityOpenPositions) {
      commodityOpenPositions.forEach((position) => {
        const groupName = position.ccp_undrlyng;
        if (!groupedData[groupName]) {
          groupedData[groupName] = {
            contracts: [],
            totalQty: 0,
          };
        }
        groupedData[groupName].contracts.push(position);
        groupedData[groupName].totalQty += position.ccp_opnpstn_qty;
      });
    }
    return groupedData;
  };

  const renderTable = () => {
    const groupedData = groupDataByGroupName();

  
    if (error) return <p>{error}</p>;

    return (
      <div className="positions-table">
        <div className="inner-box">
          {Object.keys(groupedData).length > 0 ? (
            Object.keys(groupedData).map((groupName, groupIndex) => (
              <div key={groupIndex} className="group-section">
                <div
                  className="group-header"
                  onClick={() => toggleGroupExpansion(groupName)}
                >
                  <button className="circular-btn">
                    {expandedGroups[groupName] ? "-" : "+"}
                  </button>
                  <span style={{ marginLeft: "10px" }}>{groupName}</span>
                </div>
                {expandedGroups[groupName] && (
                  <table className="table table-striped">
                    <thead>
                    <thead>
                      <tr>
                        <th>Contract</th>
                        <th>Position</th>
                        <th>Quantity</th>
                        <th>Average Price</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    </thead>
                    <tbody>
                      {groupedData[groupName].contracts.map((contractData, index) => (
                        <tr key={index}>
                          <td>
                            <input
                              type="checkbox"
                              checked={checkedContracts[contractData.ccp_undrlyng] || false}
                              onChange={() => handleCheckboxChange(contractData.ccp_undrlyng)}
                            />
                            <span style={{ marginLeft: "5px" }}>{contractData.ccp_undrlyng}</span>
                          </td>
                          <td>{contractData.ccp_opnpstn_flw || "0"}</td>
                          <td>{contractData.ccp_opnpstn_qty || "0"}</td>
                          <td>{!isNaN(contractData.ccp_avg_prc) ? contractData.ccp_avg_prc.toFixed(2) : "0"}</td>
                          <td>
                            <button
                              className="btn btn-outline-primary btn-sm"
                              onClick={() => handleSquareOff(contractData)}
                            >
                              Square Off
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
                <table className="table table-striped">
                  <tbody>
                    <tr className="font-weight-bold">
                      <td>Group Total</td>
                      <td></td>
                      <td>{groupedData[groupName].totalQty || "0"}</td>
                      <td></td>
                      <td>
                        <button
                          className="btn btn-outline-danger btn-sm"
                          onClick={handleSquareOffAll}
                        >
                          Square Off All
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            ))
          ) : (
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>Contract</th>
                  <th>Position</th>
                  <th>Quantity</th>
                  <th>Average Price</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td colSpan="5">No data available</td>
                </tr>
              </tbody>
            </table>
          )}
        </div>
      </div>
    );
  };

  return <div>{renderTable()}</div>;
};

export default CommodityPositions;
