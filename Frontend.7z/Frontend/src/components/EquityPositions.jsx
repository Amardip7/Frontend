import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from 'react-redux';
import { fetchEquityData } from "../services/EquityService";
import { setEquityOpenPositions, setSquareOffData } from "../redux/slices/equitySlice";  // Import actions
import { setComponentType } from '../redux/slices/componentSlice';  // Adjust the path
import "../CSS/PositionsTable.css";

const EquityPositions = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const uccId = useSelector((state) => state.uccId);  // Access UCC ID from Redux
  const equityOpenPositions = useSelector((state) => state.equityData.equityOpenPositions);  // Access equity positions from Redux
  const componentType = useSelector((state) => state.component.componentType);

console.log('Current componentType:', componentType); // Should log 'Equity' if set correctly


  const [loading, setLoading] = useState(true);
  const [checkedContracts, setCheckedContracts] = useState({});

  // Fetch Equity Data based on uccId from Redux
  useEffect(() => {
    const fetchData = async () => {
      if (uccId) {
        try {
          const response = await fetchEquityData(uccId);
          const equityData = response["Equity_MTF_positions "];  // Access with trailing space
          dispatch(setEquityOpenPositions(equityData));  // Store positions in Redux
          initializeCheckedContracts(equityData);
        } catch (error) {
          console.error("Error fetching data:", error);
        } finally {
          setLoading(false);
        }
      }
    };
    fetchData();
  }, [uccId, dispatch]);

  // Initialize checked contracts
  const initializeCheckedContracts = (data) => {
    const initialCheckedContracts = {};
    if (data) {
      data.forEach((item) => {
        initialCheckedContracts[item.epb_stck_cd] = true;  // Checkboxes selected by default
      });
    }
    setCheckedContracts(initialCheckedContracts);
  };

  // Handle checkbox change
  const handleCheckboxChange = (contract) => {
    setCheckedContracts((prev) => ({
      ...prev,
      [contract]: !prev[contract],
    }));
  };

  // Handle square off button click for a single contract
  const handleSquareOff = (contract) => {
    dispatch(setSquareOffData({ contracts: [contract] }));  // Store square-off data in Redux
    // console.log('Dispatching componentType as Equity');  // Log dispatch
  dispatch(setComponentType('Equity')); 
  navigate('/squareoff'); 
  };

  // Handle square off for all checked contracts
  const handleSquareOffAll = () => {
    const contractsToSquareOff = Object.keys(checkedContracts).filter(
      (contract) => checkedContracts[contract]
    );
    const Details = contractsToSquareOff.map((contract) => {
      // const contractDetails = equityOpenPositions.find((c) => c.epb_stck_cd === contract);
      // return {
      //   contract,
      //   qty: contractDetails.epb_orgnl_pstn_qty,
      //   productType: contractDetails.epb_prdct_typ,
      //   expiryDate: contractDetails.epb_expiry_dt,
      //   exchangeCode: contractDetails.epb_xchng_cd,
      //   orderType: "Market",
      //   fullContractDetails: contractDetails,  // Full contract details
      // };

      return equityOpenPositions.find((c) => c.epb_stck_cd === contract);

      

    });
    const contractsDetails = {
      contracts: Details,
    };

    dispatch(setSquareOffData({ contracts: contractsDetails }));
    console.log('Dispatching componentType as Equity');  // Log dispatch
    dispatch(setComponentType('Equity')); 
    navigate('/squareoff'); 

    
  };

  // Calculate the group total
  const calculateGroupTotal = () => {
    return equityOpenPositions.reduce(
      (total, item) => total + item.epb_orgnl_pstn_qty,
      0
    );
  };

  // Render the table
  const renderTable = () => {
    return (
      <div className="positions-table">
        <div className="inner-box">
          {equityOpenPositions && equityOpenPositions.length > 0 ? (
            <>
              <table className="table table-striped">
                <thead>
                  <tr>
                    <th>Stock</th>
                    <th>Expiry Date</th>
                    <th>Open Quantity</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {equityOpenPositions.map((contractData, index) => (
                    <tr key={index}>
                      <td>
                        <input
                          type="checkbox"
                          checked={checkedContracts[contractData.epb_stck_cd] || false}
                          onChange={() => handleCheckboxChange(contractData.epb_stck_cd)}
                        />
                        <span style={{ marginLeft: "5px" }}>{contractData.epb_stck_cd}</span>
                      </td>
                      <td>{contractData.epb_expiry_dt}</td>
                      <td>{contractData.epb_orgnl_pstn_qty}</td>
                      <td>
                        <button
                          className="btn btn-secondary"
                          onClick={() => handleSquareOff(contractData)}
                        >
                          Square Off
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {/* Group total row */}
              <table className="table table-striped" style={{ marginBottom: "0" }}>
                <tbody>
                  <tr className="font-weight-bold">
                    <td>Group Total</td>
                    <td></td>
                    <td>{calculateGroupTotal()}</td>
                    <td>
                      <button
                        className="btn btn-outline-danger btn-sm"
                        onClick={handleSquareOffAll}
                      >
                        Square Off All
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </>
          ) : (
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>Stock</th>
                  <th>Expiry Date</th>
                  <th>Open Quantity</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td colSpan="4">No data available</td>
                </tr>
              </tbody>
            </table>
          )}
        </div>
      </div>
    );
  };

  return <div>{renderTable()}</div>;
};

export default EquityPositions;
