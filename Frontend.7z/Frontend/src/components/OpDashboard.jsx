import React, { useState } from 'react';
import { Button, Form, FormControl, Container, Row, Col, Card } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { setUccId } from '../redux/slices/uccIdSlice';
import '../CSS/OpDashboard.css';

const OpDashboard = () => {
  const [uccIdInput, setUccIdInput] = useState('');
  const [error, setError] = useState(null);
  const [uccIdError, setUccIdError] = useState(''); // Add a new state for UCC ID validation errors
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const validateUccId = () => {
    if (uccIdInput.trim() === '') {
      return 'UCC ID is required';
    }
    if (uccIdInput.length < 10) {
      return 'UCC ID must be at least 10 characters long';
    }
    // Ensure only digits are entered (no alphabets or other characters)
    const digitRegex = /^[0-9]+$/;
    if (!digitRegex.test(uccIdInput)) {
      return 'UCC ID must contain only digits';
    }
    return '';
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationError = validateUccId();

    if (validationError) {
      setUccIdError(validationError); // Set the validation error message
      return;
    }

    console.log('Submitted UCC ID:', uccIdInput);

    try {
      dispatch(setUccId(uccIdInput));
      navigate('/f&o/positions');
    } catch (error) {
      setError('Failed to fetch F&O data. Please try again.');
      console.error('Error fetching F&O data:', error);
    }
  };

  return (
    <div className="home-page">
      <Container className="mt-5 text-center">
        <Row className="justify-content-center">
          <Col md={6}>
            <Card className="p-4 box-style">
              <Form onSubmit={handleSubmit}>
                <Form.Group controlId="formUCCID">
                  <Form.Label><b>ENTER CUSTOMER UCC ID:</b></Form.Label>
                  <FormControl
                    type="text"
                    value={uccIdInput}
                    onChange={(e) => {
                      setUccIdInput(e.target.value);
                      setUccIdError(''); // Clear validation error on change
                    }}
                    className="ucc-input"
                    isInvalid={uccIdError !== ''}
                  />
                  <Form.Control.Feedback type="invalid">
                    {uccIdError}
                  </Form.Control.Feedback>
                </Form.Group>
                <Button variant="warning" type="submit" className="submit-btn">
                  SUBMIT
                </Button>
              </Form>
            </Card>
          </Col>
        </Row>
        {error && (
          <Row className="mt-4">
            <Col>
              <p className="text-danger">{error}</p>
            </Col>
          </Row>
        )}
      </Container>
    </div>
  );
};

export default OpDashboard;
