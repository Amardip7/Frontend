import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { fetchFOData } from '../services/F&OService';
import { setFOOpenPositions, setSquareOffData } from '../redux/slices/foSlice';
import '../CSS/FuturesandOptionsPositions.css';

const FuturesandOptions = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const uccId = useSelector((state) => state.uccId);  // Access UCC ID from Redux
  const [loading, setLoading] = useState(true);
  const [expandedGroups, setExpandedGroups] = useState({});
  const [checkedContracts, setCheckedContracts] = useState({});
  const foOpenPositions = useSelector((state) => state.foData.foOpenPositions);  // Access open positions from Redux

  useEffect(() => {
    const fetchData = async () => {
      if (uccId) {
        try {
          const response = await fetchFOData(uccId);
          dispatch(setFOOpenPositions(response.positions));  // Store positions in Redux
          initializeExpandedGroups(response.positions);
        } catch (error) {
          console.error(error);
        } finally {
          setLoading(false);
        }
      }
    };
    fetchData();
  }, [uccId, dispatch]);

  const initializeExpandedGroups = (data) => {
    const initialExpandedGroups = {};
    const initialCheckedContracts = {};
    if (data) {
      data.forEach((contract) => {
        const groupName = contract.FFO_CONTRACT.split("-")[1];
        if (!initialExpandedGroups[groupName]) {
          initialExpandedGroups[groupName] = true; // Expand by default
        }
        initialCheckedContracts[contract.FFO_CONTRACT] = true; // Checkboxes selected by default
      });
    }
    setExpandedGroups(initialExpandedGroups);
    setCheckedContracts(initialCheckedContracts);
  };

  const toggleGroupExpansion = (group) => {
    setExpandedGroups((prev) => ({
      ...prev,
      [group]: !prev[group],
    }));
  };

  const handleCheckboxChange = (contract) => {
    setCheckedContracts((prev) => ({
      ...prev,
      [contract]: !prev[contract],
    }));
  };

  const handleSquareOff = (contractDetails) => {
    // Square off data as an array for consistency
    const squareOffData = { contracts: [contractDetails] };  // Always wrap in array
    dispatch(setSquareOffData(squareOffData));  // Store square-off data in Redux
    navigate('/squareoff');
  };
  
  const handleSquareOffAll = (groupName, groupedData) => {
    const contractsToSquareOff = Object.keys(checkedContracts).filter(
      (contract) => checkedContracts[contract] && contract.includes(groupName)
    );
  
    const contractsDetails = contractsToSquareOff.map((contract) =>
      groupedData[groupName].contracts.find(c => c.FFO_CONTRACT === contract)
    );
  
    if (contractsDetails.length > 0) {
      dispatch(setSquareOffData({ contracts: contractsDetails }));  // Store square-off data in Redux
      navigate('/squareoff');
    } else {
      console.warn('No contracts selected for square-off');
    }
  };
  
  const groupDataByGroupName = () => {
    const groupedData = {};
    if (foOpenPositions) {
      foOpenPositions.forEach((contract) => {
        const groupName = contract.FFO_CONTRACT.split("-")[1];
        if (!groupedData[groupName]) {
          groupedData[groupName] = {
            contracts: [],
            totalQty: 0,
          };
        }
        groupedData[groupName].contracts.push(contract);
        groupedData[groupName].totalQty += contract.FCP_OPNPSTN_QTY;
      });
    }
    return groupedData;
  };

  const renderTable = () => {
    const groupedData = groupDataByGroupName();
    
    return (
      <div className="positions-table">
        <div className="inner-box">
          {Object.keys(groupedData).length > 0 ? (
            Object.keys(groupedData).map((groupName, groupIndex) => (
              <div key={groupIndex} className="group-section">
                <div
                  className="group-header"
                  onClick={() => toggleGroupExpansion(groupName)}
                >
                  <button className="circular-btn">
                    {expandedGroups[groupName] ? "-" : "+"}
                  </button>
                  <span style={{ marginLeft: "10px" }}>{groupName}</span>
                </div>
                {expandedGroups[groupName] && (
                  <table className="table table-striped">
                    <thead>
                      <tr>
                        <th>Contract</th>
                        <th>Position</th>
                        <th>Quantity</th>
                        <th>Average Price</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {groupedData[groupName].contracts.map((contractData, index) => (
                        <tr key={index}>
                          <td>
                            <input
                              type="checkbox"
                              checked={checkedContracts[contractData.FFO_CONTRACT] || false}
                              onChange={() => handleCheckboxChange(contractData.FFO_CONTRACT)}
                            />
                            <span style={{ marginLeft: "5px" }}>{contractData.FFO_CONTRACT}</span>
                          </td>
                          <td>{contractData.FFO_PSTN || "0"}</td>
                          <td>{contractData.FCP_OPNPSTN_QTY || "0"}</td>
                          <td>{!isNaN(contractData.avgCostPrice) ? contractData.avgCostPrice.toFixed(2) : "0"}</td>
                          <td>
                            <button
                              className="btn btn-outline-primary btn-sm mr-1"
                              onClick={() => handleSquareOff(contractData)}
                            >
                              Square Off
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
                <table className="table table-striped" style={{ marginBottom: "0" }}>
                  <tbody>
                    <tr className="font-weight-bold">
                      <td>Group Total</td>
                      <td></td>
                      <td>{groupedData[groupName].totalQty || "0"}</td>
                      <td></td>
                      <td>
                        <button
                          className="btn btn-outline-danger btn-sm mr-1"
                          onClick={() => handleSquareOffAll(groupName, groupedData)}
                        >
                          Square Off All
                        </button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            ))
          ) : (
            <table className="table table-striped">
              <thead>
                <tr>
                  <th>Contract</th>
                  <th>Position</th>
                  <th>Quantity</th>
                  <th>Average Price</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td colSpan="5">No data available</td>
                </tr>
              </tbody>
            </table>
          )}
        </div>
      </div>
    );
  };
  

  return <div>{renderTable()}</div>;
};

export default FuturesandOptions;