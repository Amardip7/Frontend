// import React from 'react';
// import { useSelector } from 'react-redux';
// import { useNavigate } from 'react-router-dom';
// import '../CSS/SquareOff.css';

// const SquareOff = () => {
//     const navigate = useNavigate();
//     const squareOffData = useSelector((state) => state.foData.squareOffData); // Access square-off data from Redux
//     const uccId = useSelector((state) => state.uccId); // Access uccId from Redux

//     // Check if it's a single contract or an array of contracts
//     const contracts = squareOffData?.contracts || [];  // Ensure square-off data is always an array

// console.log('squareOffData:', squareOffData);
// console.log('contracts:', contracts);

// const totalQty = contracts.reduce((acc, contract) => acc + Number(contract.FCP_OPNPSTN_QTY), 0);

// const handleSquareOff = () => {
//   if (!contracts.length) return;

//   // Navigate to OrderVerification page with first contract's product type
//   navigate(`/squareoff/order/${uccId}/${contracts[0]?.FCP_PRDCT_TYP}`);
// };


//     return (
//         <div className="square-off-container">
//             <div className="square-off-header">
//                 <h3>SQUARE OFF</h3>
//             </div>
//             <div className="square-off-body">
//                 {contracts.length > 0 ? (
//                     contracts.map((contractData, index) => (
//                         <div key={index} className="square-off-row">
//                             <div className="row-item">
//                                 <span className="label">Stock : </span>
//                                 <span className="value">{contractData.FFO_CONTRACT}</span>
//                             </div>
//                             <div className="row-item">
//                                 <span className="label">Position Quantity : </span>
//                                 <span className="value">{contractData.FCP_OPNPSTN_QTY}</span>
//                             </div>
//                         </div>
//                     ))
//                 ) : (
//                     <p>No contract data found</p>
//                 )}
//                 <div className="square-off-row">
//                     <span className="label">Square Off Quantity : </span>
//                     <input 
//                         type="text" 
//                         className="input-box" 
//                         value={totalQty} 
//                         readOnly  
//                     />
//                 </div>
//             </div>
//             <div className="square-off-footer">
//                 <button className="back-btn" onClick={() => navigate(-1)}>Back</button>
//                 <button className="square-off-button" onClick={handleSquareOff}>Square Off</button>
//             </div>
//         </div>
//     );
// };

// export default SquareOff;

import React from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import '../CSS/SquareOff.css';

const SquareOff = () => {
    const navigate = useNavigate();
    const squareOffData = useSelector((state) => state.foData.squareOffData || state.equityData.squareOffData || state.commodityData.squareOffData); // Access square-off data from Redux across F&O, Equity, and Commodity
    const componentType = useSelector((state) => state.component.componentType); // Get the current component type (F&O, Equity, Commodity)
    const uccId = useSelector((state) => state.uccId); // Access uccId from Redux

    console.log('squareOffData:', squareOffData);
    console.log('componentType:', componentType);

    // Unify contract handling (ensure contracts is an array)
    const contracts = squareOffData?.contracts || [];

    // Unify field extraction for different data structures (F&O, Equity, Commodity)
    const getContractField = (contract, fieldNames) => {
        for (const field of fieldNames) {
            if (contract[field] !== undefined) {
                return contract[field];
            }
        }
        return ''; // Return empty string if no field matches
    };

    // Unify total quantity calculation across different segments
    const totalQty = contracts.reduce((acc, contract) => {
        return acc + Number(getContractField(contract, ['ccp_opnpstn_qty', 'epb_orgnl_pstn_qty', 'FCP_OPNPSTN_QTY']));
    }, 0);

    const handleSquareOff = () => {
        if (!contracts.length) return;

        // Identify product type dynamically from contract fields
        const productType = getContractField(contracts[0], ['ccp_prdct_typ', 'epb_pstn_stts', 'FCP_PRDCT_TYP']);

        // Navigate to OrderVerification page with product type and uccId
        navigate(`/squareoff/order/${uccId}/${productType}`);
    };

    return (
        <div className="square-off-container">
            <div className="square-off-header">
                <h3>SQUARE OFF</h3>
            </div>
            <div className="square-off-body">
                {contracts.length > 0 ? (
                    contracts.map((contract, index) => (
                        <div key={index} className="square-off-row">
                            <div className="row-item">
                                <span className="label">Stock : </span>
                                <span className="value">
                                    {getContractField(contract, ['ccp_undrlyng', 'epb_stck_cd', 'FFO_CONTRACT'])}
                                </span>
                            </div>
                            <div className="row-item">
                                <span className="label">Position Quantity : </span>
                                <span className="value">
                                    {getContractField(contract, ['ccp_opnpstn_qty', 'epb_orgnl_pstn_qty', 'FCP_OPNPSTN_QTY'])}
                                </span>
                            </div>
                        </div>
                    ))
                ) : (
                    <p>No contract data found</p>
                )}
                <div className="square-off-row">
                    <span className="label">Square Off Quantity : </span>
                    <input 
                        type="text" 
                        className="input-box" 
                        value={totalQty} 
                        readOnly  
                    />
                </div>
            </div>
            <div className="square-off-footer">
                <button className="back-btn" onClick={() => navigate(-1)}>Back</button>
                <button className="square-off-button" onClick={handleSquareOff}>Square Off</button>
            </div>
        </div>
    );
};

export default SquareOff;
