import React, { useEffect } from 'react';
import { Container, Nav, Navbar, Button } from 'react-bootstrap';
import { useSelector } from 'react-redux';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import iciciLogo from '../assets/icici_logo.svg';
import '../CSS/NavigationBar.css';

function NavigationBar({ primaryLinks, secondaryLinks }) {
  const navigate = useNavigate();
  const location = useLocation();
  const uccId = useSelector((state) => state.uccId);  // Access UCC ID from Redux

  // Logout handler
  const handleLogout = () => {
    sessionStorage.removeItem('uccId');
    navigate('/'); // Redirect to login page
  };

  // Navigate to /positions if path matches primary link exactly
  useEffect(() => {
    const primaryMatch = primaryLinks.find(link => location.pathname.startsWith(link.to));
    if (primaryMatch && location.pathname === primaryMatch.to) {
      const positionsPath = `${primaryMatch.to}/positions`;
      navigate(positionsPath);
    }
  }, [location.pathname, primaryLinks, navigate]);

  // Check if current page is the Operational Dashboard
  const isOpDashboard = location.pathname.includes('/opdashboard');

  // Dynamic Download Function
  const handleDownload = async (category, fileType) => {
    try {
      const response = await fetch(`http://localhost:8000/download/${category}/${fileType}`, {
        method: 'GET',
        headers: {
          'Accept': 'application/octet-stream',
        },
      });

      if (!response.ok) throw new Error('Network response was not ok');

      // Create a blob and download the file
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `${category}_${fileType}.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to download file:', error);
    }
  };

  // Button action based on current page
  const handleButtonClick = () => {
    if (isOpDashboard) {
      handleLogout(); // Logout action on opdashboard page
    } else {
      navigate('/opdashboard'); // Go to Dashboard action elsewhere
    }
  };

  return (
    <>
      {/* First Navbar with logo and logout/dashboard button */}
      <Navbar expand="lg" className="custom-navbar">
        <Container fluid className="align-items-center">
          <Navbar.Brand as={NavLink} to="/" className="d-flex align-items-center">
            <img
              src={iciciLogo}
              width="200"
              height="50"
              className="icicilogo"
              alt="ICICI Direct Logo"
            />
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="navbar-nav" />
          <Navbar.Collapse id="navbar-nav" className="justify-content-end">
  <Nav className="me-auto custom-nav">
    {/* Primary Links */}
    {!isOpDashboard && primaryLinks.map((link, index) => (
      <React.Fragment key={link.to}>
        <Nav.Link
          as={NavLink}
          to={link.to}
          className={({ isActive }) => (isActive ? 'active' : '')}
        >
          {link.label}
        </Nav.Link>
        {index < primaryLinks.length - 1 && <span className="separator ms-2">|</span>}
      </React.Fragment>
    ))}
  </Nav>
  <Button
    variant="outline-danger"
    className="orange-button"
    onClick={handleButtonClick}
  >
    {isOpDashboard ? 'Logout' : 'Go to Dashboard'}
  </Button>
</Navbar.Collapse>

        </Container>
      </Navbar>

      {/* Second Navbar with User Icon and UCC ID */}
      {!isOpDashboard && primaryLinks.some(link => location.pathname.startsWith(link.to)) && (
        <Navbar expand="lg" className="custom-navbar second-navbar">
          <Container fluid className="position-relative">
            {/* User Icon and UCC ID on the left side */}
            <div id="uccId-display">
              <i className="fas fa-user"></i> {/* Font Awesome user icon */}
              <span style={{ marginLeft: '10px' }}> {uccId}</span> {/* Display UCC ID */}
            </div>
            <Navbar.Toggle aria-controls="navbar-nav-second" />
            <Navbar.Collapse id="navbar-nav-second">
              <Nav className="me-auto custom-nav">
                {secondaryLinks.map((link, index) => (
                  <React.Fragment key={link.to}>
                    <Nav.Link
                      as={NavLink}
                      to={link.to}
                      className={({ isActive }) => (isActive ? 'active' : '')}
                    >
                      {link.label}
                    </Nav.Link>
                    {index < secondaryLinks.length - 1 && <span className="separator ms-2">|</span>}
                  </React.Fragment>
                ))}
              </Nav>
            </Navbar.Collapse>
          </Container>
        </Navbar>
      )}
    </>
  );
}

export default NavigationBar;