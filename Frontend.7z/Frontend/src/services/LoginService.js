import axios from 'axios';

export const logindata = async (formData) => {
  try {
    const response = await axios.post('http://localhost:8090/login', formData);
    console.log(response.data);
    return response.data;
  } catch (error) {
    throw error;
  }
};
