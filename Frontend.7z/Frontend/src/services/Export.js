
import axios from "axios";
import { PORT_No, BASE_URL } from "../services/ApiConstant";

const baseURL = `${BASE_URL}:${PORT_No}`;

export async function fetchExportData() {
  try {
//     const response = await axios.get(`${baseURL}/CCPService/${uccId}`);
//     console.log('API Response:', response.data); // Log the response data
//     return response.data;
//   } catch (error) {
//     console.log("Error fetching Commodity position data:", error);
//     throw error;
const response = await fetch('http://localhost:8000/download/fno/trd_dtls', { // Update the port if needed
    method: 'GET',
    headers: {
        'Accept': 'application/octet-stream',
    },
});


if (!response.ok) {
    throw new Error('Network response was not ok');
}
console.log(response.json)

  }
  catch (error) {
    console.error('Failed to download file:', error);
}
};





